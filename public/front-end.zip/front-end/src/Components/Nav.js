import React from 'react'

export default function Nav() {
  return (
    <div>Nav</div>
  )
}
